name: "Nevlin Font"
designer: "Nevlin, Rasmus Andersson"
license: "OFL"
category: "SANS_SERIF"
date_added: "2026-10-16"
fonts {
  name: "Nevlin Font"
  style: "normal"
  weight: 400
  filename: "NevlinFont-Regular.ttf"
  post_script_name: "NevlinFont-Regular"
  full_name: "Nevlin Font Regular"
  copyright: "Copyright 2026 The Nevlin Font Project Authors (https://github.com/nevlin-ltd/nevlin-font). Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)."
}
fonts {
  name: "Nevlin Font"
  style: "normal"
  weight: 500
  filename: "NevlinFont-Medium.ttf"
  post_script_name: "NevlinFont-Medium"
  full_name: "Nevlin Font Medium"
  copyright: "Copyright 2026 The Nevlin Font Project Authors (https://github.com/nevlin-ltd/nevlin-font). Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)."
}
fonts {
  name: "Nevlin Font"
  style: "normal"
  weight: 600
  filename: "NevlinFont-SemiBold.ttf"
  post_script_name: "NevlinFont-SemiBold"
  full_name: "Nevlin Font SemiBold"
  copyright: "Copyright 2026 The Nevlin Font Project Authors (https://github.com/nevlin-ltd/nevlin-font). Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)."
}
fonts {
  name: "Nevlin Font"
  style: "normal"
  weight: 700
  filename: "NevlinFont-Bold.ttf"
  post_script_name: "NevlinFont-Bold"
  full_name: "Nevlin Font Bold"
  copyright: "Copyright 2026 The Nevlin Font Project Authors (https://github.com/nevlin-ltd/nevlin-font). Copyright 2016 The Inter Project Authors (https://github.com/rsms/inter)."
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
source {
  repository_url: "https://github.com/nevlin-ltd/nevlin-font"
}
