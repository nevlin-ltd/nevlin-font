# Nevlin Font — core Latin development candidate

This separate candidate targets Google Fonts Latin Core plus auxiliary Latin characters, financial symbols and separators (374 encoded codepoints). The full Inter-derived beta and its broad language coverage remain unchanged in the sibling candidate directory.

Editable Glyphs and UFO sources are in sources/. The sources retain the full design inventory; repertoire.json explicitly selects the distributed characters at build time. OpenType closure preserves necessary components and substitutions. The build adds an explicit editable ccmp rule for i/j/į dot removal before above accents; this rule is in build.py and the generated UFO features. No prebuilt font is a build input.

Use Python 3.12, install requirements-lock.txt in a virtual environment, then run python build.py and python prepare_submission.py. Outputs are fonts/ttf and fonts/woff2. The googlefonts directory is a review package, not an approved release.

Most letterforms and inherited spacing are derived from Inter 4.001. Attribution and SIL OFL notices are preserved. This preparation does not establish original-design eligibility or Google Fonts acceptance.

Validation results and unresolved review points are recorded in VALIDATION.md. No submission has been sent.

Run `python check_core.py` for coverage, tabular numerals and accent regression checks. Run `fontbakery check-googlefonts googlefonts/nevlinfont/*.ttf` for the full profile.
