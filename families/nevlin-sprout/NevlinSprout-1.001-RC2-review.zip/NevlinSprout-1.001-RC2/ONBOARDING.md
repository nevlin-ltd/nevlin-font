# Before submitting Nevlin Sprout

Prepared:
- Original source drawings, editable UFOs, deterministic build recipe.
- Four TTF/WOFF2 weights and a Google-layout review directory.
- GF Latin Core and auxiliary European character coverage.
- License, article, specimen and QA evidence; review request #11130 is open.
- Original 16 warnings resolved; no failures in the full Google profile.

Still required or awaiting assessment:
1. Completed: the new family and sources are public at
   https://github.com/nevlin-ltd/nevlin-font/tree/main/families/nevlin-sprout.
   The earlier family is preserved.
2. Fresh virtual-environment build completed on the same macOS host; all eight
   binaries match the candidate and all structural checks pass. GitHub CI and
   other-machine/platform validation remain outstanding.
3. Confirm the family name. Google's naming rules restrict copyright-holder
   names and registered trademarks. “Nevlin Sprout” is a working name and its
   acceptance/uniqueness has not been established. Ask before treating it as final.
4. Confirm the actual copyright-holder/designer attribution and complete the
   appropriate Google contributor agreements. No CLA is represented as signed.
5. Resolve or obtain an accepted disposition for the eight vendor/subset warnings.
   Microsoft registration has not been confirmed in this task. Keep `NONE` until
   confirmation; do not assert that NVLN has already been registered.
6. Obtain independent type-design and native-language review, particularly
   accents, joined forms, spacing/kerning and small-size readability. Run the
   candidate on Windows, Android, iOS and live Figma text.
7. Submitted: The original Google design/eligibility review request #11129 included
   AI-assistance disclosure and links the earlier Inter-derived family inquiry.
   It was closed requesting Latin Core corrections and the official template: https://github.com/google/fonts/issues/11129

The candidate is uploaded and review issue #11129 is closed; 1.001 corrects the identified coverage gap. No pull request
or catalog publication has occurred.
The previous issue https://github.com/google/fonts/issues/11128 is unchanged.

References:
- https://googlefonts.github.io/gf-guide/onboarding.html
- https://googlefonts.github.io/gf-guide/qa.html

Version 1.001 RC2 is now resubmitted with the official New Font template:
https://github.com/google/fonts/issues/11130. No acceptance is claimed.

Repository layout and source build updated; see documentation/requirements-status.txt
for verified work versus pending human and Google decisions.
